import sys 
import subprocess


line ="""Please be advised there has been a failure while running {0}""".format(sys.argv[1])

cmd = """echo '{0}'|hdfs dfs -put -f - {1}""".format(line,sys.argv[2]) 

returned_value = subprocess.call(cmd, shell=True)  # returns the exit code in unix

