import sys
workflow=sys.argv[1]
fileName='message.txt'
f = open(filename, 'a')
f.write("Please be advised that there was a failure in workflow ")
f.write(workflow)
f.write("\nRegards, Oozie")
f.close()
